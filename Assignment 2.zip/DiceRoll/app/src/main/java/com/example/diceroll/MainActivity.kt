package com.example.diceroll

import android.annotation.SuppressLint
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rollButtonMA: Button = findViewById(R.id.button_AM)
        rollButtonMA.setOnClickListener {
            rollDiceMA()


            val toastMA = Toast.makeText(this,"Dice Rolled",Toast.LENGTH_LONG)
            toastMA.show()
        }
    }

    private fun rollDiceMA() {
        val diceMA = DiceMA(6)
        val cubeRoll = diceMA.rollMA()
        val textViewAM: TextView = findViewById(R.id.textViewAM)
        textViewAM.text = cubeRoll.toString()
        val imageView: ImageView =findViewById(R.id.imageView)
        imageView.setImageResource(R.drawable.six)
        when(cubeRoll)
        {
            1 -> imageView.setImageResource(R.drawable.one)
            2 -> imageView.setImageResource(R.drawable.two)
            3 -> imageView.setImageResource(R.drawable.three)
            4 -> imageView.setImageResource(R.drawable.four)
            5 -> imageView.setImageResource(R.drawable.five)
            6 -> imageView.setImageResource(R.drawable.six)
        }
    }

    class DiceMA (val numSidesMA: Int)
    {
        fun rollMA(): Int {
            return (1..numSidesMA).random()
        }
    }
}