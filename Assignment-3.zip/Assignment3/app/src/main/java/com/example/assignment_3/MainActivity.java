package com.example.assignment_3;

import android.app.Activity;

public class MainActivity extends Activity {
}
