package com.example.assignment_3
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {

                return false
            }
        }

        val initialUrl = "https://www.google.com"
        webView.loadUrl(initialUrl)

        amazonButton.setOnClickListener {
            val amazonUrl = "https://www.amazon.com"
            openWebView(amazonUrl)
        }

        flipkartButton.setOnClickListener {
            val flipkartUrl = "https://www.flipkart.com"
            openWebView(flipkartUrl)
        }

        facebookButton.setOnClickListener {
            val facebookUrl = "https://www.facebook.com"
            openWebView(facebookUrl)
        }
    }

    private fun openWebView(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }
}
